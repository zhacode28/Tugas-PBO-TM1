/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo.pkg2;

/**
 *
 * @author zahidahhanumalzahra
 */
class Unggas extends Hewan {
    public Unggas() {
        System.out.println("Saya adalah unggas");
    }

     @Override
    public void berkembangbiak() {
        System.out.println("Saya berkembang biak dengan cara bertelur");
    }
    
    @Override
    public void gerak() {
        System.out.println("Saya bergerak dengan cara Terbang");
    }
}



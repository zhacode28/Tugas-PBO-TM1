/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo.pkg2;

/**
 *
 * @author zahidahhanumalzahra
 */
    public class Tumbuhan extends MakhlukHidup {
    private String akar;
    

    public void setAkar(String akar) {
    this.akar = akar;
    }

    public String getAkar() {
    return akar;
    }

    @Override
    public void berkembangbiak() {
        System.out.println("Saya berkembang biak dengan cara generatif");
    }
}



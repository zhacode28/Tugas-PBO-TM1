/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo.pkg2;

/**
 *
 * @author zahidahhanumalzahra
 */
public class MakhlukHidup {
   
    public void berkembangbiak() {
        System.out.println("Saya berkembang biak dengan cara Generatif");
    }

    public void gerak() {
        System.out.println("Saya bergerak dengan cara");
    }
}



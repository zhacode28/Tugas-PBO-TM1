/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pbo.pkg2;

/**
 *
 * @author zahidahhanumalzahra
 */
class Mamalia extends Hewan {
    public Mamalia() {
        System.out.println("Saya adalah mamalia");
    }
    
     @Override
    public void berkembangbiak() {
        System.out.println("Saya berkembang biak dengan cara beranak");
    }
    
     @Override
    public void gerak() {
        System.out.println("Saya bergerak dengan cara Berpegangan di ranting pohon");
    }
}

